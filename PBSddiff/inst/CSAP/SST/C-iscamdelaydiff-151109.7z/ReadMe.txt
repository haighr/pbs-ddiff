May 2014: All instances of plogis using dvar_vector replaced with code consistent with the new StatsLib.h lib recently introduced into ADMB build.

Functions that were formerly structured: 
log_sel(j)(i) = log( plogis(age,p1,p2)+tiny );  

Are now structured:
log_sel(j)(i) = log( plogis<dvar_vector>(age,p1,p2)+tiny );  

Code will not compile otherwise

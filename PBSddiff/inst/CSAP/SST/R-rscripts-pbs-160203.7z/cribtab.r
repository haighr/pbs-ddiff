## PJS crib table (35 scenarios)
cribtab = data.frame(
  run = 1:35,
  #sens = c(2,13,14,15,0,3,17,20,19,18,16,1,4,5,6,7,8,9,11,10,12,21,99,22:23,24:29,32:35),
  sens = c(3,17,18,19,0,4,21,24,23,22,20,2,5,6,7,8,9,10,12,11,14,1,rep(NA,7),15,16,13,rep(NA,3)),
  label = c("M.10", "M.10+k12", "M.10+k14", "M.10+k18", "M.08", 
  "M.12", "M.10+sig0.3|sigR.8", "M.10+syr=1991", "M.10+wgtsig.05", "M.10+sig0.1|sigR.4", "M.10+k20",
   "M.06", "k12", "k14", "k18", "k20", "sig0.3|sigR.8", "sig0.1|sigR.4", "syr=1990", "wgtsig.05", "noCPUE",
  "M.03", "no1998mnW",
  paste0("NMFS-M.0",rep(c(3,6),each=3),"+k",rep(c(21,16,13),2)),  ## NMFS growth scenario (24 thru 29)
  "onlyCPUE", "noTriennial", ## 30 & 31
  "syr=1996",
  paste0("NMFS-M.08+k",c(21,16,13))  ## NMFS growth scenario with M=0.08 (33 to 35)
  ),
  SG  = c(1,2,2,2,0,1,3,4,3,3,2,1,2,2,2,2,3,3,4,3,5,1,99,rep(99,6),5,5,4,rep(99,3))
)
row.names(cribtab)=paste0("assess",pad0(cribtab$run,2))
cribtab$Slab[!is.na(cribtab$sens)] = paste0("S",pad0(cribtab$sens[!is.na(cribtab$sens)],2))
cribtab$k    = c(16,12,14,18,rep(16,6),20,16,12,14,18,20,rep(16,7),rep(c(21,16,13),2),rep(16,3),c(21,16,13))
cribtab$M    = c(rep(0.1,4),0.08,0.12,rep(0.1,5),0.06,rep(0.08,9),0.03,0.08,rep(0.03,3),rep(0.06,3),rep(0.08,6))
cribtab$sigO = c(rep(0.2,6),0.3,rep(0.2,2),0.1,rep(0.2,6),0.3,0.1,rep(0.2,17))
cribtab$sigR = c(rep(0.6,6),0.8,rep(0.6,2),0.4,rep(0.6,6),0.8,0.4,rep(0.6,17))
cribtab$sigW = c(rep(0.15,8),0.05,rep(0.15,10),0.05,rep(0.15,15))
cribtab$t1   = c(rep(1980,7),1991,rep(1980,10),1990,rep(1980,12),1996,rep(1980,3))
cribtab$I    = c(rep("1:6",20),"1:5",rep("1:6",8),"6",rep("2:6",2),rep("1:6",3))
cribtab$Rlab = cribtab$RG = rep(NA,nrow(cribtab))
cribtab[paste0("assess",pad0(c(5,12,22,24:29,33:35),2)),"RG"] = 1:12
cribtab[paste0("assess",pad0(c(5,12,22,24:29,33:35),2)),"Rlab"] = paste0("R",pad0(1:12,2))

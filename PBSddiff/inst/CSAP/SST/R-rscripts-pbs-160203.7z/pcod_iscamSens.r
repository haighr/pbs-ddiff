#**********************************************************************************
# ccamSens.r
# This file contains the code necessary to plot sensitivities overlaid on top
# of one another by sensitivity group which is set in the file 'SensitivityGroup'
# in each Scenario folder.  Scenarios with the same sensitivity group will be plotted
# together.  The 'SensitivityGroup' file should have a single number in it, nothing more.
# The Ref model will be SensitivityGroup=0 and will be plotted against all other
# Sensitivity groups.
# 
# Assumes the opList has been built and contains the SensitivityGroup element:
# opList[[scenario]][[4]]$SensitivityGroup
#
# Author            : Chris Grandin
# Development Date  : December 2011 - January 2012
# Modified          : Rowan Haigh (2015-09-09)

#
#**********************************************************************************

fig.base.vs.sens <- function(sensitivityGroup=NULL,whichPlot="biomass",ylimit=6,useMaxYlim=T,lty=2,lwd=2,pch=20,offset=0.3,opacity="20")
{
	# plots Spawning stock biomiass, depletion, and recruitment for a given sensitivity group
	#  - plot the MCMC posterior data for each, with confidence limits
	#  - offset is the number of years to offset each vertical bar from each other.
	#  - opacity is a two digit string from 00-99 
	# whichPlot can be:
	# 1. "biomass"
	# 2. "depletion"
	# 3. "recruits"

	on.exit(expandGraph(mfrow=c(1,1), new=FALSE))
	base   <- 0
	color  <- 1
	colors <- color
	nocrib = !exists("cribtab",envir=.GlobalEnv)

	SGs  = getWinVal()$scenarioHeader[,2]
	if (is.null(sensitivityGroup)) sensitivityGroup=getWinVal()$entrySensitivityGroup
	if (is.null(SGs) && nocrib){
		cat("WARNING: No Sensitivtiy Groups found\n"); return(invisible("No Sensitivity Groups")) }
	else if (is.null(SGs)){
		if (using.sweave) SGs = CRIBTAB$SG ## before subsetting non-sensitivities
		else  SGs = cribtab$SG
	}
	if (!any(SGs==0)) {
		cat("WARNING: No Reference Case (0) found in Sensitivtiy Groups\n"); return(invisible("No Ref Case")) }

	## Get index numbers for the base and sensitivity group
	ibase = grep(base,SGs)[1]
	isens = grep(sensitivityGroup,SGs)  ## numerical index of sensitivityGroup in SGs

	plotR <- TRUE
	baseRep <- opList[[ibase]][[4]]
	baseName = strsplit(opList[[ibase]][[1]],"/")[[1]][3]
	if (nocrib) {
		runNames <- paste0("Ref: ",strsplit(opList[[ibase]][[1]],"/")[[1]][3]) # Gets the run's folder name out of the reletive path
		sensNum = 0:31
		oruns   = c(5,12,1,6,13:18,20,19,21,2:4,11,7,10,9,8,22:31)        ## order of the runs starting with base/ref (make sure this matches `oruns' in `modelResults.Rnw')
		names(sensNum) = paste0("assess",pad0(oruns,2))
	} else {
		#cribtab = cribtab[!is.na(cribtab$sens),]
		runNames = paste0(cribtab[baseName,c("Slab","label")],collapse=": ")
		sensNum  = cribtab[order(cribtab$sens),"sens"]
		oruns    = cribtab[order(cribtab$sens),"run"]
		names(sensNum) = row.names(cribtab[order(cribtab$sens),])
		sensNum[is.na(sensNum)] = 99
	}
	senscols = rep("white",length(oruns))
	names(senscols) = oruns                       ## label sensitivity colours with actual run number
	ncols = grep("^0|99",sensNum,invert=TRUE)
	scols = rainbow(length(ncols),end=0.75)
	senscols[1]= "gainsboro"
	senscols[ncols] = scols

	osens = NULL
	for (i in isens)
		osens=c(osens, strsplit(opList[[i]][[1]],"/")[[1]][3] )
	names(isens) = osens
#browser();return()

###########################
### BIOMASS  
	if (whichPlot == "biomass") {
		#Get the maximum year from the longest time series for xlim - i.e. might be comparing results from different lengths of data
		#Need to do this here so the xlim is long enough
		sensyr <- baseRep$yrs
		mcbt <- baseRep$mc.sbt/1000
		post.bt <- as.data.frame(window(mcmc(mcbt),start=Burn+1,thin=Thin))
		MaxBt <- apply(post.bt,2,quantile,probs=c(0.025,0.5,0.975))
		MaxBt <- max(MaxBt)
		for(scenario in isens){
			#Get max xlim
			maxnyr <- length(baseRep$yrs)
			yrtest <- opList[[scenario]][[4]]$yrs
			if(length(yrtest) > maxnyr) {
				maxnyr <- length(opList[[scenario]][[4]]$yrs)
				sensyr <- opList[[scenario]][[4]]$yrs
			}
			#Now get max ylim
			mcbt <- opList[[scenario]][[4]]$mc.sbt/1000
			post.bt <- as.data.frame(window(mcmc(mcbt),start=Burn+1,thin=Thin))
			ScBt <- apply(post.bt,2,quantile,probs=c(0.025,0.5,0.975))
			if(max(ScBt) > MaxBt) MaxBt <- max(ScBt)
		}
		mcbo <- baseRep$mc$bo/1000
		post.bo <- as.data.frame(window(mcmc(mcbo),start=Burn+1,thin=Thin))
		boci <- apply(post.bo,2,quantile,probs=c(0.025,0.5,0.975))

		mcbt <- baseRep$mc.sbt/1000
		post.bt <- as.data.frame(window(mcmc(mcbt),start=Burn+1,thin=Thin))
		btci <- apply(post.bt,2,quantile,probs=c(0.025,0.5,0.975))

		if(getWinVal()$maxBiomassSensYlim){
			yUpperLimit <- 1.2*MaxBt
		} else {
			yUpperLimit <- getWinVal()$biomassSensYlim
		}
		matplot(baseRep$yrs,
			t(btci),
			type="l",
			col=color,
			lty=c(2,1,2),
			lwd=2,
			ylim=c(0,yUpperLimit),
			xlim=c(min(sensyr),max(sensyr)),
			xlab="Year",
			ylab="Biomass",
			main="Biomass",
			las=1)

		# Shade the confidence interval
		xx <- c(baseRep$yrs,rev(baseRep$yrs))
		yy <- c(btci[1,],rev(btci[3,]))
		shade <- getShade(color,opacity)
		polygon(xx,yy,density=NA,col=shade)
		# End shade the confidence interval

		points(baseRep$yrs[1]-0.8,boci[2],col=color,pch=1)
		arrows(baseRep$yrs[1]-0.8,boci[1],baseRep$yrs[1]-0.8,boci[3],col=color, code=0, lwd=1.5)
		currOffset <- offset

		for(scenario in isens){
			mcbo <- opList[[scenario]][[4]]$mc$bo/1000
			post.bo <- as.data.frame(window(mcmc(mcbo),start=Burn+1,thin=Thin))
			boci <- apply(post.bo,2,quantile,probs=c(0.025,0.5,0.975))
			mcbt <- opList[[scenario]][[4]]$mc.sbt/1000
			post.bt <- as.data.frame(window(mcmc(mcbt),start=Burn+1,thin=Thin))
			btci <- apply(post.bt,2,quantile,probs=c(0.025,0.5,0.975))
			color <- color + 1
			colors <- c(colors,color)

			par(new=T)
			matplot(opList[[scenario]][[4]]$yrs,
				t(btci),
				type="l",
				col=color,
				lty=c(2,1,2),
				lwd=2,
				xlim=c(min(sensyr),max(sensyr)),
				ylim=c(0,yUpperLimit),
				xlab="",
				ylab="",
				las=1)

			# Shade the confidence interval
			xx <- c(opList[[scenario]][[4]]$yrs,rev(opList[[scenario]][[4]]$yrs))
			yy <- c(btci[1,],rev(btci[3,]))
			shade <- getShade(color,opacity)
			polygon(xx,yy,density=NA,col=shade)
			# End shade the confidence interval

			par(new=F)
			points(opList[[scenario]][[4]]$yrs[1]-0.8+currOffset,boci[2],col=color,pch=1)
			arrows(opList[[scenario]][[4]]$yrs[1]-0.8+currOffset,boci[1],opList[[scenario]][[4]]$yrs[1]-0.8+currOffset,boci[3],col=color, code=0, lwd=1.5)
			currOffset <- currOffset + offset
			runNames <- c(runNames,paste0("Sens ",scenario,": ",strsplit(opList[[scenario]][[1]],"/")[[1]][3]))
		}
#browser();return()
		lty <- c(rep(1,(length(runNames))))
		legend("topright",runNames,lty=lty,col=colors,bty="n", lwd=2)
		
		filename <- paste("fig.sensi.group",sensitivityGroup,".biomass",sep="")
		saveFig(filename)
###########################
### DEPLETION
	} else if (whichPlot == "depletion") {
		#Get the maximum year from the longest time series for xlim - i.e. might be comparing results from different lengths of data
		#Need to do this here so the xlim is long enough
		for(scenario in isens){
			maxnyr <- length(baseRep$yrs)
			yrtest <- opList[[scenario]][[4]]$yrs
			if(length(yrtest) >maxnyr) {
				maxnyr <- length(opList[[scenario]][[4]]$yrs)
				sensyr <- opList[[scenario]][[4]]$yrs
			} else sensyr <- baseRep$yrs
		}
		mcdt    <- baseRep$mc.sbdepletion
		post.dt <- as.data.frame(window(mcmc(mcdt),start=Burn+1,thin=Thin))
		dtci    <- apply(post.dt,2,quantile,probs=c(0.025,0.5,0.975))

		if(getWinVal()$maxDepletionSensYlim){
			yUpperLimit <- 2*max(dtci)
		} else {
			yUpperLimit <- getWinVal()$depletionSensYlim
		}
		matplot(baseRep$yrs,
			t(dtci),
			type="l",
			col=color,
			lty=c(2,1,2), 
			lwd=2,
			ylim=c(0,yUpperLimit),
			 xlim=c(min(sensyr),max(sensyr)),
			xlab="Year",
			ylab="Depletion",
			main="Depletion")

		# Shade the confidence interval
		xx <- c(baseRep$yrs,rev(baseRep$yrs))
		yy <- c(dtci[1,],rev(dtci[3,]))
		shade <- getShade(color,opacity)
		polygon(xx,yy,density=NA,col=shade)
		# End shade the confidence interval
		abline(h=0.40, lwd=mtLineWidth, col=mtLineColor, lty=mtLineType)

		for(scenario in isens){
			mcdt <- opList[[scenario]][[4]]$mc.sbdepletion
			post.dt  <- as.data.frame(window(mcmc(mcdt),start=Burn+1,thin=Thin))
			dtci <- apply(post.dt,2,quantile,probs=c(0.025,0.5,0.975))
			color <- color + 1				  
			colors <- c(colors,color)

			par(new=T)
			matplot(opList[[scenario]][[4]]$yrs,
				t(dtci),
				type="l",
				col=color,
				lty=c(2,1,2), 
				lwd=2,
				xlim=c(min(sensyr),max(sensyr)),
				ylim=c(0,yUpperLimit),
				xlab="",
				ylab="")

			# Shade the confidence interval
			xx <- c(opList[[scenario]][[4]]$yrs,rev(opList[[scenario]][[4]]$yrs))
			yy <- c(dtci[1,],rev(dtci[3,]))
			shade <- getShade(color,opacity)
			polygon(xx,yy,density=NA,col=shade)
			par(new=F)
			runNames <- c(runNames,paste0("Sens ",scenario,": ",strsplit(opList[[scenario]][[1]],"/")[[1]][3]))
		}
		lty <- c(rep(1,(length(runNames))),mtLineType)
		lwd <- c(rep(2,(length(runNames))),mtLineWidth)
		colors <- c(colors,mtLineColor)
		runNames <- c(runNames,"Ref 0.4 B0")
		legend("topright",runNames,lty=lty,col=colors,bty="n", lwd=lwd)
		filename <- paste("fig.sensi.group",sensitivityGroup,".depletion",sep="")
		saveFig(filename)

###########################
### RECRUITS  
	} else if (whichPlot == "recruits") {
		#Get the maximum year from the longest time series for xlim - i.e. might be comparing results from different lengths of data
		#Need to do this here so the xlim is long enough
		sage    = baseRep$sage
		rnyr    = length(baseRep$yr)
		baseryr = baseRep$yr[(1+sage):rnyr]
		ymax    = max(baseRep$mc.rt/1000)*10
#print(ymax)
		for(scenario in c(ibase,isens)){
			ryrtest <- opList[[scenario]][[4]]$yr
			if(length(ryrtest) >length(baseRep$yr)) {
				rnyr <- length(opList[[scenario]][[4]]$yr)
				sensryr <- opList[[scenario]][[4]]$yr[(1+sage):rnyr]
			} else sensryr <- baseryr
			ymax2 = max(sapply(opList[[1]][[4]]$mc.rt/1000,quantile,0.975))
			ymax  = max(ymax,ymax2)
#print(ymax2)
		}

		mc <- baseRep$mc.rt/1000
		mc.rt <- as.data.frame(window(mcmc(mc),start=Burn+1,thin=Thin)) 
		rt <- apply(mc.rt,2,quantile,probs=c(0.025,0.5,0.975))

		if(getWinVal()$maxRecruitmentSensYlim){
			yUpperLimit <- ymax
		} else {
			yUpperLimit <- getWinVal()$recruitmentSensYlim
		}

		xp <- plot(baseryr,
			rt[2,],
			type="p",
			pch=20,
			col=color,
			xlim=c(min(sensryr),max(sensryr)),
			ylim=c(0,yUpperLimit),
			xlab="Year", 
			ylab="Recruits (millions)",
			main="Recruits",
			las=1)
		arrows(baseryr, rt[1, ],baseryr,rt[3,],code=3,angle=90,length=0.01,col=color)
		abline(h=median(as.matrix(mc.rt)),col=2,lty=2)
		abline(h=mean(as.matrix(mc.rt)),col=3,lty=2)
		currOffset <- offset

		for(scenario in isens){
			sage  <-opList[[scenario]][[4]]$sage
			rnyr  <- length(opList[[scenario]][[4]]$yr)
			ryr   <- opList[[scenario]][[4]]$yr[(1+sage):rnyr]
			mc    <- opList[[scenario]][[4]]$mc.rt/1000
			mc.rt <- as.data.frame(window(mcmc(mc),start=Burn+1,thin=Thin)) 
			rt    <- apply(mc.rt,2,quantile,probs=c(0.025,0.5,0.975))
			color <- color + 1
			colors<- c(colors,color)

			par(new=T)
			plot(ryr+currOffset,
				rt[2,],
				pch=20,
				#xlim=c(min(ryr),max(ryr)),
				xlim=c(min(sensryr),max(sensryr)),
				ylim=c(0,yUpperLimit),
				col=color,
				xlab="",
				ylab="",
				las=1,
				axes=F)
			arrows(ryr+currOffset, rt[1, ],ryr+currOffset,rt[3,],code=3,angle=90,length=0.01,col=color)
			par(new=F)
			currOffset <- currOffset + offset
			runNames <- c(runNames,paste0("Sens ",scenario,": ",strsplit(opList[[scenario]][[1]],"/")[[1]][3]))
		}
		lty <- c(rep(1,(length(runNames))),2,2)
		runNames <- c(runNames,"base long-term median","base long-term mean")
		legend("topright",
				runNames,
				lty=lty,
				col=c(colors,2,3),
				bty="n",
				lwd=2) 
		filename <- paste("fig.sensi.group",sensitivityGroup,".recruits",sep="")
		saveFig(filename)

###########################
### REFERENCE POINTS BOXPLOTS  
	} else if (whichPlot == "refpts") {
#browser();return()
		outline  = getWinVal()$outline  ## for boxplot outliers (or not)
		if (is.null(outline)) outline = FALSE
		useLog   = getWinVal()$useLog
		if (is.null(useLog)) useLog = FALSE
		if (useLog) {
			scaleFn  = log10; scaleNm = "log[10]~bgroup(\"[\","
		} else {
			scaleFn = function(x){x}; scaleNm = ""
		}

		mcbo   <- baseRep$mc$bo/1000
		mcbmsy <- baseRep$mc$bmsy/1000
		mcmsy  <- baseRep$mc$msy #/1000
		mcfmsy <- baseRep$mc$fmsy
		mcdt   <- baseRep$mc.sbdepletion
		mcdt   <- mcdt[,dim(mcdt)[2]]
		mcut   <- 1-exp(-subset(baseRep$mcproj,TAC==0)[,paste0("F",baseRep$lastYr)])
		mcumsy <- 1-exp(-baseRep$mc$fmsy)

		post.bo   <- as.vector(window(mcmc(mcbo),start=Burn+1,thin=Thin))
		post.bmsy <- as.vector(window(mcmc(mcbmsy),start=Burn+1,thin=Thin))
		post.msy  <- as.vector(window(mcmc(mcmsy),start=Burn+1,thin=Thin))
		post.fmsy <- as.vector(window(mcmc(mcfmsy),start=Burn+1,thin=Thin))
		post.dt   <- as.vector(window(mcmc(mcdt),start=Burn+1,thin=Thin))
		post.ut   <- as.vector(window(mcmc(mcut),start=Burn+1,thin=Thin))
		post.umsy <- as.vector(window(mcmc(mcumsy),start=Burn+1,thin=Thin))
		post.ut.umsy = post.ut/post.umsy
		boxCols   <- senscols[1]

		for(scenario in ibase){
			#runNames <- paste0("Ref: ",strsplit(opList[[scenario]][[1]],"/")[[1]][3])
			AxisName = "S00"
		}
		#for(scenario in isens){
		for (scenarioName in names(sort(sensNum[osens]))){
			scenario = isens[scenarioName]
			boxCols = c(boxCols,senscols[as.character(scenario)])
#browser();return()
			mcbo   <- opList[[scenario]][[4]]$mc$bo/1000
			mcbmsy <- opList[[scenario]][[4]]$mc$bmsy/1000
			mcmsy  <- opList[[scenario]][[4]]$mc$msy #/1000
			mcfmsy <- opList[[scenario]][[4]]$mc$fmsy
			mcdt   <- opList[[scenario]][[4]]$mc.sbdepletion
			mcdt   <- mcdt[,dim(mcdt)[2]]
			mcut   <- 1-exp(-subset(opList[[scenario]][[4]]$mcproj,TAC==0)[,paste0("F",opList[[scenario]][[4]]$lastYr)])
			mcumsy <- 1-exp(-opList[[scenario]][[4]]$mc$fmsy)

			post.bo2   <- as.vector(window(mcmc(mcbo),start=Burn+1,thin=Thin))
			post.bmsy2 <- as.vector(window(mcmc(mcbmsy),start=Burn+1,thin=Thin))
			post.msy2  <- as.vector(window(mcmc(mcmsy),start=Burn+1,thin=Thin))
			post.fmsy2 <- as.vector(window(mcmc(mcfmsy),start=Burn+1,thin=Thin))
			post.dt2   <- as.vector(window(mcmc(mcdt),start=Burn+1,thin=Thin))
			post.ut2   <- as.vector(window(mcmc(mcut),start=Burn+1,thin=Thin))
			post.umsy2 <- as.vector(window(mcmc(mcumsy),start=Burn+1,thin=Thin))
			post.ut.umsy2 = post.ut2/post.umsy2

			post.bo   <- cbind(post.bo,post.bo2)
			post.bmsy <- cbind(post.bmsy,post.bmsy2)
			post.msy  <- cbind(post.msy,post.msy2)
			post.fmsy <- cbind(post.fmsy,post.fmsy2)
			post.dt   <- cbind(post.dt,post.dt2)
			post.ut   <- cbind(post.ut,post.ut2)
			post.umsy <- cbind(post.umsy,post.umsy2)
			post.ut.umsy <- cbind(post.ut.umsy,post.ut.umsy2)

			sensName  = strsplit(opList[[scenario]][[1]],"/")[[1]][3]
			if (nocrib)
				runNamesi = paste0("Sens ",sensNum[sensName],": ",sensName)
			else
				runNamesi = paste0(cribtab[names(scenario),c("Slab","label")],collapse=": ")
			#runNamesi <- paste0("Sens ",scenario,": ",strsplit(opList[[scenario]][[1]],"/")[[1]][3])
			runNames  <- c(runNames, runNamesi)
			AxisName  <- c(AxisName,paste0(substr(runNamesi,1,1),pad0(sensNum[sensName],2)))
		}
#browser();return()

		par(mfrow=c(2,2), mar=c(2,3,2,0.5), oma=c(0,0,0,0), mgp=c(2,0.5,0))
		#par(mfrow=c(2,2), mai=c(0.3,0.5,0.4,0.2), oma=c(1.,1.2,0.2,0.1))
		#Set limits for Bo plot
		yy = scaleFn(post.bo)
		maxBSY = getWinVal()$maxBiomassSensYlim
		if (is.null(maxBSY)) maxBSY = TRUE
#browser();return()
		if(maxBSY){
			yUpperLimit = max(apply(yy,2,quantile,ifelse(outline,1,0.95)))
		} else {
			yUpperLimit <- scaleFn(getWinVal()$biomassSensYlim)
		}
		#boxplot(scaleFn(post.bo), pch=".", range=0.95,  col=boxCols, names=AxisName, main=paste(scaleNm,"B0 (1000 t)"), las=1, cex.axis=1.2, cex=1.2, ylim=c(0,yUpperLimit))
		cex.axis = ifelse(dim(yy)[[2]]>5, 0.8, 1.2)
		main = paste0("expression(",scaleNm,"italic(B[0])~(1000~t)",ifelse(useLog,",\"]\")",""),")")
		quantBox(yy, pch=".", col=boxCols, names=AxisName, main=eval(parse(text=main)), las=1,
			cex.main=1.5, cex.axis=1.2, cex=1.2, ylim=c(0,yUpperLimit), outline=outline, boxwex=0.5, xaxt="n")
		axis(1,at=1:length(AxisName),labels=AxisName,cex.axis=cex.axis)
#browser();return()
		legend("topleft",runNames, lty=1, col=boxCols,bty="n", lwd=2)

		#Set limits for depletion plot
		maxDSY = getWinVal()$maxDepletionSensYlim
		if (is.null(maxDSY)) maxDSY=TRUE
		if(maxDSY){
			yUpperLimit = max(apply(post.dt,2,quantile,ifelse(outline,1,0.95)))
		} else {
			yUpperLimit <- getWinVal()$depletionSensYlim
		}
		#boxplot(post.dt, pch=".", range=0.95, col=boxCols, names=AxisName, main="Bt / B0", las=1, cex.axis=1.2, cex=1.2, ylim=c(0,yUpperLimit))
		quantBox(post.dt, pch=".", col=boxCols, names=AxisName, main=expression(paste(italic(B[t])/italic(B)[0])), las=1,
			cex.main=1.5,cex.axis=1.2, cex=1.2, ylim=c(0,yUpperLimit), outline=outline, boxwex=0.5, xaxt="n")
		axis(1,at=1:length(AxisName),labels=AxisName,cex.axis=cex.axis)


		## Harvest rate vs. Umsy
		yUpperLimit = max(apply(post.ut.umsy,2,quantile,ifelse(outline,1,0.95)))
		#yUpperLimit = max(apply(post.fmsy,2,quantile,ifelse(outline,1,0.95)))
		#boxplot(post.fmsy, pch=".", range=0.95, col=boxCols, names=AxisName, main="FMSY (/y)", las=1, cex.axis=1.2, cex=1.2, ylim=c(0,1)) #1.1*max(post.fmsy)
		#quantBox(post.fmsy, pch=".", col=boxCols, names=AxisName, main="FMSY (/y)", las=1, 
		quantBox(post.ut.umsy, pch=".", col=boxCols, names=AxisName, main=expression(paste(italic(u[t])/italic(u)[MSY])), las=1, 
			cex.main=1.5,cex.axis=1.2, cex=1.2, ylim=c(0,yUpperLimit), outline=outline, boxwex=0.5, xaxt="n")
		axis(1,at=1:length(AxisName),labels=AxisName,cex.axis=cex.axis)

		#legend("topleft",runNames,lty=1, col=boxCols,bty="n", lwd=2)

		#Set limits for MSY plot
		yy = scaleFn(post.msy)
		maxRSY = getWinVal()$maxRefptSensYlim
		if (is.null(maxRSY)) maxRSY=TRUE
		if(maxRSY){
			yUpperLimit = max(apply(yy,2,quantile,ifelse(outline,1,0.95)))
		} else {
			yUpperLimit <- scaleFn(getWinVal()$RefptSensYlim)   #set ylimit high on GUI and assume that MSY will be smaller than Bo or Bmsy
		}
		yLowerLimit = min(apply(yy,2,quantile,ifelse(outline,0,0.05)))
		#boxplot(scaleFn(post.msy), pch=".", range=0.95 , col=boxCols, names=AxisName, main=paste(scaleNm,"MSY (1000 t)"), las=1, cex.axis=1.2, cex=1.2, ylim=c(yLowerLimit,yUpperLimit))
		main = paste0("expression(",scaleNm,"MSY~(t)",ifelse(useLog,",\"]\")",""),")")
		#quantBox(yy, pch=".", col=boxCols, names=AxisName, main=paste(scaleNm,"MSY (1000 t)"), las=1,
		quantBox(yy, pch=".", col=boxCols, names=AxisName, main=eval(parse(text=main)), las=1,
			cex.main=1.5, cex.axis=1.2, cex=1.2, ylim=c(yLowerLimit,yUpperLimit), outline=outline, boxwex=0.5, xaxt="n")
		axis(1,at=1:length(AxisName),labels=AxisName,cex.axis=cex.axis)


#		#Set limits for Bmsy plot
#		if(useMaxYlim){
#			yUpperLimit <- max(post.bmsy)
#		} else {
#			yUpperLimit <- 0.5*ylimit	#assume Bmsy smaller than Bo
#		}
#		boxplot(post.bmsy, pch=".", range=0.95, col=boxCols, names=AxisName, main="BMSY (1000 t)", las=1, cex.axis=1.2, cex=1.2, ylim=c(0,yUpperLimit))

		figDir.curr = figDir
		assign("figDir",paste0(fdScenarios,baseName[1],"/",fdFigures),envir=.GlobalEnv) ## RH temporarily override the global in case user is not in the right scenario
		filename <- paste("fig.sensi.group",sensitivityGroup,".refpts",sep="")
#browser();return()
		saveFig(filename)
		assign("figDir",figDir.curr,envir=.GlobalEnv)
	}
}

### Redefine boxplot to show quantiles (RH 150910)
### http://r.789695.n4.nabble.com/Box-plot-with-5th-and-95th-percentiles-instead-of-1-5-IQR-problems-implementing-an-existing-solution-td3456123.html
myboxplot.stats <- function (x, coef=NULL, do.conf=TRUE, do.out=TRUE)
{
  nna <- !is.na(x)
  n <- sum(nna)
  stats <- quantile(x, c(.05,.25,.5,.75,.95), na.rm = TRUE)
  iqr <- diff(stats[c(2, 4)])
  out <- x < stats[1] | x > stats[5]
  conf <- if (do.conf)
    stats[3] + c(-1.58, 1.58) * diff(stats[c(2, 4)])/sqrt(n)
  list(stats = stats, n = n, conf = conf, out = x[out & nna])
} 

boxcode = deparse(boxplot.default)
boxcode = gsub("boxplot\\.stats","myboxplot.stats",boxcode)
eval(parse(text=c("qboxplot=",boxcode)))

quantBox = function (x, use.cols = TRUE, ...) ## taken from boxplot.matrix
{
	if (rev(class(x))[1]=="matrix") {
		groups <- if (use.cols) 
			split(x, rep.int(1L:ncol(x), rep.int(nrow(x), ncol(x))))
		else split(x, seq(nrow(x)))
		if (length(nam <- dimnames(x)[[1 + use.cols]])) 
		names(groups) <- nam
		qboxplot(groups, ...)
	}
	else qboxplot(x, ...)
}
